// bnet.h
#ifndef BNET_H
#define BNET_H

int showIp(char *hostname);

#endif

