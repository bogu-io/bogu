#include <stdbool.h>
#include <stdio.h>

int main(void) {
    bool x = true;

    if (x) {
        printf("x is true!\n");
    }
}
